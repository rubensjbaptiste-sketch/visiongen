const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const WAVESPEED_KEY = process.env.WAVESPEED_API_KEY;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Rate limiting (simple in-memory — good enough for launch)
const requests = new Map();
function rateLimit(ip) {
  const now = Date.now();
  const windowMs = 60 * 60 * 1000; // 1 hour
  const max = 10; // 10 videos per IP per hour
  if (!requests.has(ip)) requests.set(ip, []);
  const times = requests.get(ip).filter(t => now - t < windowMs);
  if (times.length >= max) return false;
  times.push(now);
  requests.set(ip, times);
  return true;
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'VisionGen API running' });
});

// GENERATE VIDEO
app.post('/api/generate', async (req, res) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

  if (!rateLimit(ip)) {
    return res.status(429).json({ error: 'Too many requests. Max 10 videos per hour.' });
  }

  const { prompt, model, duration, ratio } = req.body;

  if (!prompt || prompt.trim().length < 3) {
    return res.status(400).json({ error: 'Prompt is required' });
  }
  if (!WAVESPEED_KEY) {
    return res.status(500).json({ error: 'Server not configured. Add WAVESPEED_API_KEY.' });
  }

  const safeModel = model || 'wavespeed-ai/kling-v3-0-std/text-to-video';
  const safeDur = Math.min(Math.max(parseInt(duration) || 5, 4), 10);
  const safeRatio = ['16:9','9:16','1:1'].includes(ratio) ? ratio : '16:9';

  try {
    const endpoint = `https://api.wavespeed.ai/api/v3/${safeModel}`;
    const genRes = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${WAVESPEED_KEY}`
      },
      body: JSON.stringify({
        prompt: prompt.trim(),
        duration: safeDur,
        ratio: safeRatio,
        enable_safety_checker: true
      })
    });

    if (!genRes.ok) {
      const err = await genRes.json().catch(() => ({}));
      return res.status(genRes.status).json({ error: err.message || 'WaveSpeed API error' });
    }

    const data = await genRes.json();
    const requestId = data?.data?.id;
    if (!requestId) return res.status(500).json({ error: 'No request ID returned' });

    res.json({ requestId, status: 'queued' });

  } catch (err) {
    console.error('Generate error:', err);
    res.status(500).json({ error: 'Server error — try again' });
  }
});

// POLL STATUS
app.get('/api/status/:requestId', async (req, res) => {
  const { requestId } = req.params;
  if (!requestId || !WAVESPEED_KEY) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  try {
    const pollRes = await fetch(
      `https://api.wavespeed.ai/api/v3/predictions/${requestId}/result`,
      { headers: { 'Authorization': `Bearer ${WAVESPEED_KEY}` } }
    );

    if (!pollRes.ok) return res.status(pollRes.status).json({ error: 'Poll failed' });

    const data = await pollRes.json();
    const status = data?.data?.status;
    const url = data?.data?.outputs?.[0] || null;

    res.json({ status, url });

  } catch (err) {
    console.error('Poll error:', err);
    res.status(500).json({ error: 'Poll error' });
  }
});

// Serve frontend for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✅ VisionGen running on port ${PORT}`);
  if (!WAVESPEED_KEY) console.warn('⚠️  WAVESPEED_API_KEY not set — add it in environment variables');
});
