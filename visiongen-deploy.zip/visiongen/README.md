# VisionGen — AI Video Generator
Built by Clarix · Powered by WaveSpeed AI

## Deploy in 15 Minutes (Free)

### Step 1 — Get your WaveSpeed API Key
1. Go to https://wavespeed.ai
2. Sign up free (includes free credits)
3. Go to Dashboard → API Keys → Copy your key

### Step 2 — Deploy to Render (Free)
1. Go to https://render.com and sign up free
2. Click "New +" → "Web Service"
3. Choose "Deploy from existing code" → upload this folder
   OR connect your GitHub (drag this folder to a new GitHub repo first)
4. Settings:
   - Name: visiongen
   - Runtime: Node
   - Build Command: npm install
   - Start Command: node server.js
5. Add Environment Variable:
   - Key:   WAVESPEED_API_KEY
   - Value: (paste your WaveSpeed key here)
6. Click "Create Web Service"
7. Wait ~2 minutes → Render gives you a free URL like:
   https://visiongen-xxxx.onrender.com

### Step 3 — Share your app
Share your Render URL with anyone.
They open it, type a prompt, generate videos — no account needed.

## Features
- 5 AI models: Kling 3.0 Pro, Kling 3.0 Std, WAN 2.1, HaiLuo, Seedance 1.5
- Rate limiting: 10 videos per user per hour
- API key never exposed to users
- PWA ready — users can install to home screen
- Video history saved locally
- Download & share buttons

## Local Testing
```
npm install
WAVESPEED_API_KEY=your_key_here node server.js
```
Then open http://localhost:3000

## Monetization Ideas (Future)
- Charge users credits to generate videos
- Offer premium models at higher price
- White-label for real estate agents (Clarix)
- Sell access to roofing/HVAC companies for promo videos
